<div id="preview">

  <div id="preview-main" class="clearfix" style="background-image: url(<?php echo theme_get_setting('about_bg_path') ?>)">
    <div id="preview-sidebar">
      <div id="preview-block" class="preview-block">
        <h2>Etiam est risus</h2>
        <div class="preview-content">
          Maecenas id porttitor Ut enim ad minim veniam, quis nostrudfelis.
          Laboris nisi ut aliquip ex ea.
        </div>
      </div>
    </div>
    <div id="preview-content">
      <h1 id="preview-page-title">Lorem ipsum dolor</h1>
      <div id="preview-node">
        <div class="preview-content">
          Sit amet, <a>consectetur adipisicing elit</a>, sed do eiusmod tempor
          incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
          nostrud <a>exercitation ullamco</a> laboris nisi ut aliquip ex ea
          commodo consequat. Maecenas id porttitor Ut enim ad minim veniam, quis nostr udfelis.
        </div>
      </div>
    </div>
  </div>


</div>
